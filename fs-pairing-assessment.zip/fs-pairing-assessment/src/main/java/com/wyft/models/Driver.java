package com.wyft.models;

public class Driver {
	private int location;

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public Driver(int location) {
		this.location = location;
	}
}
